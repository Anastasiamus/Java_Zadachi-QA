package zadachi;

public class Zadacha13 {
    public static void main(String[] args) {
        int[]array = {2,45,6,3,50,1,2,3,60};
        System.out.println(SumOddNumbers(array));


    }
    public static int SumOddNumbers(int[]array) {
        int sumOddNumbers = 0;
        for (int i = 0; i < array.length; i++) {
            if(array[i] <=50 && array[i]%2 !=0) {
                sumOddNumbers += array[i];
            }
        }
        return sumOddNumbers;

    }
}


/*
Задача 13
Найти сумму положительных нечетных чисел, меньших 50. Написать на это код

 */