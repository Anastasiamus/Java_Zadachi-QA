package zadachi;

public class Zadacha8 {
    public static void main(String[] args) {
        double priceForOne = 20.4;

        for(int quantity = 2; quantity <= 20; ++quantity) {
            double wholePrice = (double)quantity * priceForOne;
            System.out.println(wholePrice);
        }

    }

    }


/*
Задача 8
Одна штука некоторого товара стоит 20,4
Напечатать таблицу стоимости 2, 3, ..., 20 штук этого товара.

 */