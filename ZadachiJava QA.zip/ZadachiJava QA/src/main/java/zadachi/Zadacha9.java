package zadachi;

import java.util.Scanner;

public class Zadacha9 {

    public static void main(String[] args) {

        int[] array = {1, 4, 9, 16, 25, 120};
        Scanner scr = new Scanner(System.in);
        System.out.println(" Enter the number until 120");
        int numberN = scr.nextInt();
        int result = findFirstGreaterThanN(array,numberN);
        System.out.println(result);
    }

      public static int findFirstGreaterThanN(int[]array,int numberN) {
          for (int number : array) {
              if (number > numberN) {
                  return number ;
              }
          }
          return -1;
      }
}

/*
Задача 9
Среди чисел 1, 4, 9, 16, 25, ... найти первое число, большее n.
N  вводим с клавиатуры – ответ выводим

 */