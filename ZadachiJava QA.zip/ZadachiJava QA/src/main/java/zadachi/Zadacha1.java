package zadachi;

public class Zadacha1 {
    public static void main(String[] args) {
        for(int x = 100; x < 1000; ++x) {
            int secondNumber = x / 10 % 10;
            int twoDigitNumber = x / 100 * 10 + x % 10;
            if (twoDigitNumber + 100 * secondNumber == 546) {
                System.out.println(" Number x: " + x);
                break;
            }
        }
    }
}
/*
Задача 1

В трехзначном числе x зачеркнули его вторую цифру.
Когда к образованному при этом двузначному числу слева приписали вторую цифру числа x,
то полу- чилось число 546. Найти число x.
Написать код  и вывести ответ в консоль

 */


