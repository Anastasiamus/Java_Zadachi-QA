package zadachi;

import java.util.Scanner;

public class Zadacha2 {
    public static void main(String[] args) {

            Scanner scr = new Scanner(System.in);
            System.out.println(" Enter the Number1: ");
            int m = scr.nextInt();
            System.out.println(" Enter the Number2: ");
            int n = scr.nextInt();
            if (m % n == 0) {
                System.out.println(" The Result is: " + m / n);
            } else {
                System.out.println(" m is not divisible by n without a remainder");
            }
    }
}

/*
Задача 2
Написать код Число вводится с клавиатуры и выводится в консоль ответ
Если целое число m делится нацело на целое число n, то вывести на экран ча-стное от деления,
 в противном случае вывести сообщение "m на n нацело не делится".

 */