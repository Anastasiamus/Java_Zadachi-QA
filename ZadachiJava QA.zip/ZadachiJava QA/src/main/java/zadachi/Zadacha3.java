package zadachi;

import java.util.Scanner;

public class Zadacha3 {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println(" Enter the Two-digit number: ");
        int twoDigitNumber = scr.nextInt();
        if (twoDigitNumber < 10 || twoDigitNumber > 99) {
            System.out.println(" Enter the Two-digit number: ");
        }

        new Scanner(System.in);
        System.out.println(" Enter the first Number of Two-digit number: ");
        int firstNumberOfTwoDigitNumber = scr.nextInt();
        System.out.println(" Enter the second Number of Two-digit number: ");
        int secondNumberOftTwoDigitNumber = scr.nextInt();
        if (firstNumberOfTwoDigitNumber > secondNumberOftTwoDigitNumber) {
            System.out.println(" The first Number of Two-digit number is greater then second ");
        } else if (firstNumberOfTwoDigitNumber < secondNumberOftTwoDigitNumber) {
            System.out.println("The second Number of Two-digit number is greater then first  ");
        } else {
            System.out.println(" The Numbers are are equal ");
        }

    }

    }


/*
Задача 3
Написать код Число вводится с клавиатуры и выводится в консоль ответ
Дано двузначное число. Определить:
а) какая из его цифр больше: первая или вторая;
б) одинаковы ли его цифры.

 */