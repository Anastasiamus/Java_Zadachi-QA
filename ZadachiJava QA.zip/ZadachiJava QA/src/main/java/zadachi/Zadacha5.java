package zadachi;

import java.util.Scanner;

public class Zadacha5 {
    public static void main(String[] args) {
            Scanner scr1 = new Scanner(System.in);
            System.out.println(" Enter the first side of Triangle: ");
            double a = scr1.nextDouble();
            Scanner scr2 = new Scanner(System.in);
            System.out.println(" Enter the second side of Triangle: ");
            double b = scr2.nextDouble();
            Scanner scr3 = new Scanner(System.in);
            System.out.println(" Enter the third side of Triangle: ");
            double c = scr3.nextDouble();
            if ((a != b || a == c) && (a != c || a == b) && (b != c || b == a)) {
                System.out.println(" The triangle is not isosceles ");
            } else {
                System.out.println(" The triangle is isosceles ");
            }

    }
}

/*
Задача 5

Определить, является ли треугольник со сторонами a, b, c равнобедренным.
Возможно ввести стороны треугольника и получить ответ
Число вводится с клавиатуры и выводится в консоль ответ

 */
