package zadachi;

import java.util.Scanner;

public class Zadacha10 {
    public static void main(String[] args) {

        Scanner scr = new Scanner(System.in);
        System.out.println("Enter the natural number: ");
        int number = scr.nextInt();
        int count = 0;

        String stringNumber = String.valueOf(number);
        char firstNumber = stringNumber.charAt(0);

        for (int i = 0; i < stringNumber.length(); i++) {
            if (stringNumber.charAt(i) == firstNumber) {
                count++;
            }
        }
        System.out.println(" First number meets " + count + " times");
    }
}

/*
Задача 10
Дано натуральное число. Определить, сколько раз в нем встречается первая цифра.
Число вводится с клавиатуры и выводится в консоль ответ

 */