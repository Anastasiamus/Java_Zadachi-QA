package zadachi;

import java.util.Scanner;

public class Zadacha6 {
    public static void main(String[] args) {
        Scanner scr = new Scanner(System.in);
        System.out.println(" Enter the number between 1 and 12: ");
        int month = scr.nextInt();
        if (month >= 1 && month <= 12) {
            String season = null;
            switch (month) {
                case 1:
                case 2:
                case 12:
                    season = " Winter";
                case 3:
                case 4:
                case 5:
                    season = " Spring";
                case 6:
                case 7:
                case 8:
                    season = " Summer";
                case 9:
                case 10:
                case 11:
                    season = " Autumn";
                default:
                    System.out.println(" This is" + season + ".");
            }
        } else {
            System.out.println(" Enter the number between 1 and 12 ");
        }
    }

    }



/*
Задача 6
Составить программу, которая в зависимости от порядкового номера дня ме- сяца (1, 2, ..., 12) выводит на экран время года, к которому относится этот месяц.

 */