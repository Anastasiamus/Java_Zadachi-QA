package zadachi;

public class Zadacha15 {
    public static void main(String[] args) {

        String word = "picture";
        char cr3 = word.charAt(3);
        char cr6 = word.charAt(word.length() - 1);

        System.out.println( " " + cr3 + cr6);



    }
}


/*
Задача 15
Дано слово  = “picture” .
Получить и вывести на экран в консоль буквосочетание,
состоящее из его третьего и последнего символа

 */