package zadachi;

public class Zadacha12 {
    public static void main(String[] args) {

        int number = 1234975;
        String numberString = String.valueOf(number);

        boolean isAscending = true;

        for (int i = 0; i < numberString.length() -1 ; i++) {

            if (numberString.charAt(i) > numberString.charAt(i + 1)) {
                isAscending = false;
                break;
            }
        }
        System.out.println(isAscending);
    }
}




/*
Задача 12
Дано натуральное число.
Установить, является ли последовательность его цифр при просмотре их
слева направо упорядоченной по возрастанию.
Например, для числа 1478 ответ положительный,
для чисел 1782 и 1668 — отрицательный и т. п.
*/