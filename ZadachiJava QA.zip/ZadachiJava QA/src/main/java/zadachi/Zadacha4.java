package zadachi;

import java.util.Scanner;

public class Zadacha4 {
    public static void main(String[] args) {

            Scanner scr = new Scanner(System.in);
            System.out.println(" Enter the number between -5 and 3 : ");
            int number = scr.nextInt();
            if (number >= -5 && number <= 3) {
                System.out.println(" The number is: " + number);
            } else {
                System.out.println(" The number is not correct");
            }

    }
}

/*
Задача 4
Проверить, принадлежит ли число, введенное с клавиатуры, интервалу (–5, 3).
Число вводится с клавиатуры и выводится в консоль ответ

 */